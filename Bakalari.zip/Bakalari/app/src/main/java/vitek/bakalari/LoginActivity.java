package vitek.bakalari;

import android.content.Context;
import android.graphics.PorterDuff;
import android.os.Bundle;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.Toast;

public class LoginActivity extends AppCompatActivity {
    private EditText mUserName;
    private EditText mPassword;
    private EditText mSchoolURL;
    private Button mSubmitButton;
    private ProgressBar mProgressBar;
    private ImageView mURLHelp;
    private Context mContext = this;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        mSubmitButton = findViewById(R.id.login_button);
        mURLHelp = findViewById(R.id.help);
        mProgressBar = findViewById(R.id.progressBar);
        mUserName = findViewById(R.id.user_name);
        mPassword = findViewById(R.id.password);
        mSchoolURL = findViewById(R.id.school_url);

        mProgressBar.getIndeterminateDrawable()
                .setColorFilter(ContextCompat.getColor(this, R.color.white), PorterDuff.Mode.SRC_IN );

        mSubmitButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mProgressBar.setVisibility(View.VISIBLE);
                mSubmitButton.setTextColor(getResources().getColor(android.R.color.transparent));
                mSubmitButton.setEnabled(false);
                new GetAccountInfoTask(mContext, mSchoolURL.getText().toString(), mPassword.getText().toString(), mUserName.getText().toString(), mProgressBar, mSubmitButton, mPassword, mSchoolURL).execute();
            }
        });

        mURLHelp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(mContext, "This feature is coming soon.", Toast.LENGTH_LONG).show();
            }
        });
    }

}
