package vitek.bakalari;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;

import java.util.ArrayList;
import java.util.concurrent.TimeUnit;

public class GetAccountInfoTask extends AsyncTask<Void, Void, ArrayList<String>> {
    private Intent mResultIntent;
    private SharedPreferences mSharedPreferences;
    private int mAccountCount;
    private SharedPreferences.Editor mEditor;
    private Context mContext;
    private String mSchoolURL;
    private String mPassword;
    private String mUserName;
    private ProgressBar mProgressBar;
    private Button mSubmitButton;
    private EditText mPasswordEditText;
    private EditText mSchoolURLEditText;


    public GetAccountInfoTask(Context context, String schoolURL, String password, String userName, ProgressBar progressBar, Button submitButton, EditText passwordEditText, EditText schoolURLEditText) {
        mContext = context;
        mSchoolURL = schoolURL;
        mPassword = password;
        mUserName = userName;
        mProgressBar = progressBar;
        mSubmitButton = submitButton;
        mPasswordEditText = passwordEditText;
        mSchoolURLEditText = schoolURLEditText;
    }

    @Override
    protected ArrayList<String> doInBackground(Void... voids) {
        ArrayList<String> result = new ArrayList<String>();
        // TODO: do actual downloading and parsing here
        result.add("url");
        result.add("Peterka Vítek, 9.A");
        result.add("žák");
        try {
            TimeUnit.SECONDS.sleep(2);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        return result;
    }

    @Override
    protected void onPostExecute(ArrayList<String> result) {
        mProgressBar.setVisibility(View.INVISIBLE);
        mSubmitButton.setTextColor(mContext.getResources().getColor(android.R.color.white));
        mSubmitButton.setEnabled(true);

        if (result.get(0).equals("0")){
            mResultIntent = new Intent();

            mResultIntent.putExtra("schoolURL", mSchoolURL);
            mResultIntent.putExtra("realName", result.get(1));
            mResultIntent.putExtra("username", mUserName);
            mResultIntent.putExtra("password", mPassword);
            if (result.get(2).equals("žák")){
                mResultIntent.putExtra("isParent", false);
            }
            else mResultIntent.putExtra("isParent", true);
            // TODO: Must check if username, password, address is right - if not don't finish(), show red text saying what is wrong to the user instead
            ((Activity)mContext).setResult(Activity.RESULT_OK, mResultIntent);

            mSharedPreferences = mContext.getSharedPreferences("prefs", Context.MODE_PRIVATE);
            mAccountCount = mSharedPreferences.getInt("account_count", 0);

            mEditor = mSharedPreferences.edit();
            mEditor.putInt("account_count", mAccountCount + 1);
            mEditor.putString("account_" + mAccountCount + "_username", mUserName);
            mEditor.putString("account_" + mAccountCount + "_password", mPassword);
            mEditor.putString("account_" + mAccountCount + "_school", mSchoolURL);
            mEditor.putString("account_"+ mAccountCount + "_real_name", result.get(1));
            if (result.get(2).equals("žák")){
                mEditor.putBoolean("account_" + mAccountCount + "_is_parent", false);
            }
            else mEditor.putBoolean("account_" + mAccountCount + "_is_parent", true);
            mEditor.apply();

            ((Activity)mContext).finish();
        }
        else if (result.get(0).equals("url")) {
            mSchoolURLEditText.setError("Zadaná adresa není URL adresou serveru Bakalářů.");
        }
        else if (result.get(0).equals("password")) {
            mPasswordEditText.setError("Uživatelsé jméno nebo heslo nejsou správně.");
        }

        super.onPostExecute(result);
    }

}
